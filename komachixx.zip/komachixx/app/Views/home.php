<?= $this->extend('default') ?>

<?= $this->section('style') ?>
<style>
    .header {
        background-color: #333;
        color: white;
        padding: 10px;
        text-align: center;
        font-size: 24px;
        font-weight: bold;
    }
    a {
        display: inline-block;
        padding: 7px 20px;
        background-color: #007bff;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        font-size: 16px;
    }
    a:hover {
        
    }
    </style>
    <?= $this->endSection() ?>

<?= $this->section('content') ?>
    <h1>halo dunia</h1>
    <footer class="bg-dark text-white p-3">
        <div class="text-center">


        </div>
    </footer>
<?= $this->endSection() ?>